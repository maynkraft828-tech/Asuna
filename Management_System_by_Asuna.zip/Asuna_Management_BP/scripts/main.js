console.warn("Asuna Management System v2.2: script loaded");

import { world, system } from "@minecraft/server";
import { ActionFormData, MessageFormData } from "@minecraft/server-ui";

const BOOK = "asuna:management_book";
const OWNER_TAG = "owner";
const ADMIN_TAG = "admin";
const FROZEN_TAG = "asuna_frozen";
const MUTE_PREFIX = "asuna_mute_";
const BAN_PREFIX = "asuna_ban_";

function msg(p,s){try{p.sendMessage(`§l§6[MANAGEMENT] §r§f${s}`)}catch{}}
function isOwner(p){return p.hasTag(OWNER_TAG)}
function isAdmin(p){return p.hasTag(ADMIN_TAG)&&!isOwner(p)}
function allowed(p){return isOwner(p)||isAdmin(p)}
function players(){return [...world.getPlayers()]}
function target(n){return players().find(p=>p.name===n)}
function key(prefix,n){return prefix+n.toLowerCase().replace(/[^a-z0-9_]/g,"_").slice(0,32)}
function getDP(k){try{return world.getDynamicProperty(k)}catch{return undefined}}
function setDP(k,v){try{world.setDynamicProperty(k,v)}catch{}}
const sessionSeconds = new Map();
const PLAYTIME_PREFIX = "asuna_playtime_";
function playtimeKey(name){return key(PLAYTIME_PREFIX,name)}
function totalPlaytimeSeconds(p){
 const saved=getDP(playtimeKey(p.name));
 return (typeof saved==="number"?saved:0)+((sessionSeconds.get(p.id)||0)%60);
}
function formatPlaytime(seconds){
 seconds=Math.max(0,Math.floor(seconds));
 const h=Math.floor(seconds/3600), m=Math.floor((seconds%3600)/60);
 return h>0?`${h}h ${m}m`:`${m}m`;
}
function rankName(p){return isOwner(p)?"OWNER":isAdmin(p)?"ADMIN":"PLAYER"}
function profileText(p){return `§l§fName: §e${p.name}\n§l§fPlaytime: §e${formatPlaytime(totalPlaytimeSeconds(p))}\n§l§fRank: §e${rankName(p)}`}
const durations=["5 minutes","15 minutes","30 minutes","1 hour","6 hours","24 hours"];
const ms={"5 minutes":300000,"15 minutes":900000,"30 minutes":1800000,"1 hour":3600000,"6 hours":21600000,"24 hours":86400000};

async function selectPlayer(p,title){
 const names=players().map(x=>x.name).filter(n=>n!==p.name);
 if(!names.length){msg(p,"No other players are online.");return null}
 const f=new ActionFormData().title(`§l${title}`).body(`${profileText(p)}\n\n§lSelect a player\n\n§l§8By Asuna`);names.forEach(n=>f.button(`§l${n}`));
 try{const r=await f.show(p);return r.canceled||r.selection===undefined?null:names[r.selection]}catch{msg(p,"منو باز نشد؛ فعال بودن بسته‌ها و Script API را بررسی کنید.");return null}
}
async function selectDuration(p,title){
 const f=new ActionFormData().title(`§l${title}`).body(`${profileText(p)}\n\n§lSelect duration\n\n§l§8By Asuna`);durations.forEach(d=>f.button(`§l${d}`));
 try{const r=await f.show(p);return r.canceled||r.selection===undefined?null:durations[r.selection]}catch{msg(p,"منو باز نشد؛ فعال بودن بسته‌ها و Script API را بررسی کنید.");return null}
}
async function confirm(p,title,body){
 try{const r=await new MessageFormData().title(`§l${title}`).body(`${profileText(p)}\n\n§l${body}\n\n§l§8By Asuna`).button1("§lCONFIRM").button2("§lCANCEL").show(p);return !r.canceled&&r.selection===0}catch{return false}
}
async function kick(p){
 const n=await selectPlayer(p,"KICK PLAYER");if(!n||!await confirm(p,"KICK PLAYER",`Kick ${n}?`))return;
 const t=target(n);if(!t)return msg(p,"Player is no longer online.");
 try{await t.runCommandAsync("kick @s")}catch{msg(p,"Kick command is unavailable in this version.")}
}
async function mute(p){
 const n=await selectPlayer(p,"TEMPORARY MUTE");if(!n)return;const d=await selectDuration(p,"MUTE DURATION");if(!d)return;
 const t=target(n);if(!t)return;setDP(key(MUTE_PREFIX,n),Date.now()+ms[d]);msg(p,`${n} muted for ${d}.`);msg(t,`You have been muted for ${d}.`)
}
async function ban(p){
 const n=await selectPlayer(p,"TEMPORARY BAN");if(!n)return;const d=await selectDuration(p,"BAN DURATION");if(!d)return;
 const t=target(n);if(!t)return;setDP(key(BAN_PREFIX,n),Date.now()+ms[d]);msg(p,`${n} temporarily banned for ${d}.`);
 try{await t.runCommandAsync("kick @s")}catch{msg(p,"Temporary ban saved, but kick failed.")}
}
async function teleportTo(p){
 const n=await selectPlayer(p,"TELEPORT TO PLAYER");if(!n)return;const t=target(n);if(!t)return;
 try{p.teleport(t.location,{dimension:t.dimension});msg(p,`Teleported to ${n}.`)}catch{msg(p,"Teleport failed.")}
}
async function bring(p){
 const n=await selectPlayer(p,"BRING PLAYER");if(!n)return;const t=target(n);if(!t)return;
 try{t.teleport(p.location,{dimension:p.dimension});msg(p,`${n} teleported to you.`)}catch{msg(p,"Teleport failed.")}
}
async function weather(p){
 const f=new ActionFormData().title("§lCHANGE WEATHER").body("§lChoose weather");["CLEAR","RAIN","THUNDER"].forEach(x=>f.button(`§l${x}`));
 try{const r=await f.show(p);if(r.canceled||r.selection===undefined)return;await p.runCommandAsync(["weather clear","weather rain","weather thunder"][r.selection]);msg(p,`Weather set to ${["CLEAR","RAIN","THUNDER"][r.selection]}.`)}catch{msg(p,"Weather change failed.")}
}
async function freeze(p,on){
 const n=await selectPlayer(p,on?"FREEZE PLAYER":"UNFREEZE PLAYER");if(!n)return;const t=target(n);if(!t)return;
 if(on)t.addTag(FROZEN_TAG);else t.removeTag(FROZEN_TAG);msg(p,`${n} ${on?"frozen":"unfrozen"}.`)
}
async function kill(p){
 const n=await selectPlayer(p,"KILL PLAYER");if(!n||!await confirm(p,"KILL PLAYER",`Kill ${n}?`))return;const t=target(n);if(!t)return;
 try{t.kill();msg(p,`${n} was killed.`)}catch{msg(p,"Could not kill player.")}
}
async function setAdmin(p){
 const n=await selectPlayer(p,"SET ADMIN");if(!n)return;const t=target(n);if(!t)return;
 if(isOwner(t))return msg(p,"Cannot change an owner here.");
 t.addTag(ADMIN_TAG);msg(p,`${n} is now an ADMIN.`);msg(t,"You are now an ADMIN.")
}
async function ownerMenu(p){
 const labels=["SET ADMIN","TEMPORARY MUTE","TEMPORARY BAN","KICK PLAYER","SET DAY","SET NIGHT","TELEPORT TO PLAYER","BRING PLAYER","CHANGE WEATHER","FREEZE PLAYER","UNFREEZE PLAYER","KILL PLAYER"];
 const f=new ActionFormData().title("§l§6OWNER MENU").body(`${profileText(p)}\n\n§lOwner controls\n\n§l§8By Asuna`);labels.forEach(x=>f.button(`§l${x}`));
 try{const r=await f.show(p);if(r.canceled||r.selection===undefined)return;if(!isOwner(p))return msg(p,"OWNER access required.");
 switch(r.selection){case 0:return setAdmin(p);case 1:return mute(p);case 2:return ban(p);case 3:return kick(p);case 4:await p.runCommandAsync("time set day");return msg(p,"Time set to DAY.");case 5:await p.runCommandAsync("time set night");return msg(p,"Time set to NIGHT.");case 6:return teleportTo(p);case 7:return bring(p);case 8:return weather(p);case 9:return freeze(p,true);case 10:return freeze(p,false);case 11:return kill(p)}}catch{msg(p,"خطای منو؛ هر دو بسته و Script API باید فعال باشند.")}
}
async function adminMenu(p){
 const f=new ActionFormData().title("§l§cADMIN MENU").body(`${profileText(p)}\n\n§lAdmin controls\n\n§l§8By Asuna`);["TEMPORARY BAN","KICK PLAYER","TEMPORARY MUTE"].forEach(x=>f.button(`§l${x}`));
 try{const r=await f.show(p);if(r.canceled||r.selection===undefined)return;if(!allowed(p))return msg(p,"ADMIN access required.");
 if(r.selection===0)return ban(p);if(r.selection===1)return kick(p);if(r.selection===2)return mute(p)}catch{msg(p,"خطای منو؛ هر دو بسته و Script API باید فعال باشند.")}
}
async function mainMenu(p){
 const f=new ActionFormData().title("§l§6ASUNA MANAGEMENT").body(`${profileText(p)}

§l§8By Asuna`);
 f.button("§l§cADMIN MENU");f.button("§l§6OWNER MENU");
 try{const r=await f.show(p);if(r.canceled||r.selection===undefined)return;
  if(r.selection===0){if(!allowed(p))return msg(p,"دسترسی ادمین ندارید.");return adminMenu(p)}
  if(r.selection===1){if(!isOwner(p))return msg(p,"این بخش فقط برای اونر است.");return ownerMenu(p)}
 }catch{msg(p,"خطای منو؛ هر دو بسته و Script API باید فعال باشند.")}
}
function openMenu(p){
 if(!p || !p.isValid) return;
 if(!allowed(p)) return msg(p,"دسترسی ندارید. برای مالک شدن اجرا کنید: /tag @s add owner");
 return mainMenu(p);
}
// Bedrock 1.21.50-compatible custom item use handler. This does not consume the book.
const lastBookOpen = new Map();
try {
  system.beforeEvents.startup.subscribe(({ itemComponentRegistry }) => {
    itemComponentRegistry.registerCustomComponent("asuna:management_use", {
      onUse(event) {
        const player = event.source;
        if (!player || player.typeId !== "minecraft:player") return;
        const now = Date.now();
        const previous = lastBookOpen.get(player.id) || 0;
        if (now - previous < 900) return;
        lastBookOpen.set(player.id, now);
        system.runTimeout(() => {
          try { if (player.isValid) openMenu(player); }
          catch (err) {
            try { msg(player, "خطا در باز کردن منو؛ بسته‌های رفتاری و منابع و Script API را بررسی کنید."); } catch {}
            console.warn("Asuna menu open error: " + err);
          }
        }, 1);
      }
    });
  });
} catch (err) { console.warn("Asuna component registration failed: " + err); }
// Fallback listener for runtimes that dispatch the global itemUse event.
try {
  world.afterEvents.itemUse.subscribe((event) => {
    if (!event || !event.itemStack || event.itemStack.typeId !== BOOK) return;
    const player = event.source;
    if (!player || player.typeId !== "minecraft:player") return;
    const now = Date.now();
    const previous = lastBookOpen.get(player.id) || 0;
    if (now - previous < 900) return;
    lastBookOpen.set(player.id, now);
    system.runTimeout(() => { try { if (player.isValid) openMenu(player); } catch (err) { console.warn("Asuna fallback menu error: " + err); } }, 1);
  });
} catch (err) { console.warn("Asuna global itemUse subscription failed: " + err); }
console.warn("Asuna Management System v2.2 loaded for Bedrock 1.21.50; server API 1.16.0");
// Temporary mute enforcement only; no chat command is used to open the menu.
try { world.beforeEvents.chatSend.subscribe(e=>{
 const until=getDP(key(MUTE_PREFIX,e.sender.name));
 if(typeof until==="number"&&until>Date.now()){e.cancel=true;system.run(()=>msg(e.sender,"You are muted and cannot chat yet."))}
 else if(typeof until==="number"&&until<=Date.now())setDP(key(MUTE_PREFIX,e.sender.name),0)
}); } catch (err) { console.warn("Asuna: chatSend subscription unavailable", err); }
try { world.afterEvents.playerSpawn.subscribe(e=>{
 const p=e.player;system.runTimeout(()=>{const until=getDP(key(BAN_PREFIX,p.name));if(typeof until==="number"&&until>Date.now()){try{p.runCommandAsync("kick @s")}catch{}msg(p,"You are temporarily banned.")}else if(typeof until==="number"&&until<=Date.now())setDP(key(BAN_PREFIX,p.name),0)},20)
}); } catch (err) { console.warn("Asuna: playerSpawn subscription unavailable", err); }
system.runInterval(()=>{
 for(const p of players()){
  const next=(sessionSeconds.get(p.id)||0)+1;
  sessionSeconds.set(p.id,next);
  if(next%60===0){const k=playtimeKey(p.name);const saved=getDP(k);setDP(k,(typeof saved==="number"?saved:0)+60);}
 }
},20);
system.runInterval(()=>{for(const p of players())if(p.hasTag(FROZEN_TAG)){try{p.addEffect("slowness",40,{amplifier:255,showParticles:false});p.addEffect("jump_boost",40,{amplifier:128,showParticles:false})}catch{}}},20);
