Asuna Management System v2.1 - Bedrock 1.21.50
Install both packs. Remove/disable old Asuna pack copies first. Enable the Behavior Pack and Resource Pack. Add owner tag with: /tag @s add owner. Get the book: /give @s asuna:management_book. The book is designed to open the menu without being consumed. This build was structurally checked but not tested inside a live Minecraft client.
